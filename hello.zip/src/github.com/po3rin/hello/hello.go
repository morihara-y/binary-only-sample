// package hello is sample of binary-only package

//go:binary-only-package

package hello
